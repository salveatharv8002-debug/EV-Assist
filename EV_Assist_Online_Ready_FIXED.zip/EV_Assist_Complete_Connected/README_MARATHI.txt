# EV Assist - Complete Connected Project

## Folder structure
- frontend/ -> React + Vite UI
- backend/ -> Express + MongoDB + JWT API

## 1) Frontend
Copy your existing `public/image33.png` into:
`frontend/public/image33.png`

Open a terminal in `frontend`:
```bash
npm install
npm run dev
```
Use the Local URL shown by Vite. This project is configured for `http://localhost:5174`.

## 2) Backend
Open another terminal in `backend`:
```bash
npm install
```
Copy `.env.example` to `.env`.

Default local MongoDB:
`MONGO_URI=mongodb://127.0.0.1:27017/ev_assist`

If you use MongoDB Atlas, replace MONGO_URI with your Atlas connection string.

Then:
```bash
npm start
```

Backend health:
`http://localhost:5000/api/health`

## What is connected
- Signup -> MongoDB
- Login -> JWT authentication
- Profile -> MongoDB
- Service requests -> MongoDB
- Request status -> MongoDB
- Service history -> MongoDB
- Rating/review -> MongoDB
- Notifications -> MongoDB
- Location coordinates -> saved with request
- Frontend API -> Express backend

## Important
This is a local/demo assistance platform. Mechanic and charging-station cards are sample data and Google Maps links. Real live mechanic availability, dispatch, payments, and emergency services require real provider APIs and production backend logic.

ONLINE WEBSITE:
For a public link, deploy frontend to Vercel, backend to Render, and use MongoDB Atlas. See DEPLOY_NOW_MARATHI.txt.
