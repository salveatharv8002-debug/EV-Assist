import express from "express";
import Notification from "../models/Notification.js";
import { auth } from "../middleware/auth.js";

const router = express.Router();

router.get("/", auth, async (req, res) => {
  try {
    const notifications = await Notification.find({ user: req.userId }).sort({ createdAt: -1 }).limit(20);
    res.json({ notifications });
  } catch {
    res.status(500).json({ message: "Could not load notifications." });
  }
});

router.post("/", auth, async (req, res) => {
  try {
    const { title, text } = req.body;
    if (!title || !text) return res.status(400).json({ message: "Title and text are required." });
    const notification = await Notification.create({ user: req.userId, title, text });
    res.status(201).json({ notification });
  } catch {
    res.status(500).json({ message: "Could not create notification." });
  }
});

router.delete("/", auth, async (req, res) => {
  try {
    await Notification.deleteMany({ user: req.userId });
    res.json({ message: "Notifications cleared." });
  } catch {
    res.status(500).json({ message: "Could not clear notifications." });
  }
});

export default router;
