import express from "express";
import Request from "../models/Request.js";
import Notification from "../models/Notification.js";
import { auth } from "../middleware/auth.js";

const router = express.Router();

const makeRequestId = () => "EV-" + Math.floor(100000 + Math.random() * 900000);

router.get("/", auth, async (req, res) => {
  try {
    const requests = await Request.find({ user: req.userId }).sort({ createdAt: -1 });
    res.json({ requests });
  } catch {
    res.status(500).json({ message: "Could not load requests." });
  }
});

router.post("/", auth, async (req, res) => {
  try {
    const { type, message = "", estimatedCost = "", latitude = null, longitude = null } = req.body;
    if (!["Breakdown", "Mechanic", "Battery", "Charging"].includes(type)) {
      return res.status(400).json({ message: "Invalid service type." });
    }

    const request = await Request.create({
      user: req.userId,
      requestId: makeRequestId(),
      type,
      message,
      estimatedCost,
      latitude,
      longitude
    });

    await Notification.create({
      user: req.userId,
      title: "Request Created",
      text: `${type} assistance request ${request.requestId} is pending.`
    });

    res.status(201).json({ request });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Could not create request." });
  }
});

router.patch("/:id/status", auth, async (req, res) => {
  try {
    const allowed = ["Pending", "Accepted", "Mechanic On The Way", "Completed"];
    const { status } = req.body;
    if (!allowed.includes(status)) return res.status(400).json({ message: "Invalid status." });

    const request = await Request.findOneAndUpdate(
      { _id: req.params.id, user: req.userId },
      { status },
      { new: true }
    );
    if (!request) return res.status(404).json({ message: "Request not found." });

    await Notification.create({
      user: req.userId,
      title: `Request ${status}`,
      text: `${request.requestId} is now ${status}.`
    });

    res.json({ request });
  } catch {
    res.status(500).json({ message: "Could not update request status." });
  }
});

router.patch("/:id/review", auth, async (req, res) => {
  try {
    const { rating, review = "" } = req.body;
    if (!Number.isInteger(Number(rating)) || Number(rating) < 1 || Number(rating) > 5) {
      return res.status(400).json({ message: "Rating must be between 1 and 5." });
    }

    const request = await Request.findOneAndUpdate(
      { _id: req.params.id, user: req.userId, status: "Completed" },
      { rating: Number(rating), review },
      { new: true }
    );
    if (!request) return res.status(404).json({ message: "Completed request not found." });

    await Notification.create({
      user: req.userId,
      title: "Review Submitted",
      text: "Thank you for your feedback."
    });

    res.json({ request });
  } catch {
    res.status(500).json({ message: "Could not submit review." });
  }
});

export default router;
