import express from "express";
import User from "../models/User.js";
import { auth } from "../middleware/auth.js";

const router = express.Router();

router.get("/", auth, async (req, res) => {
  const user = await User.findById(req.userId).select("-passwordHash");
  if (!user) return res.status(404).json({ message: "User not found." });
  res.json({ user: { id: user._id, name: user.name, email: user.email, phone: user.phone, vehicle: user.vehicle } });
});

router.put("/", auth, async (req, res) => {
  try {
    const { name, phone, vehicle } = req.body;
    if (!name || !phone || !vehicle) return res.status(400).json({ message: "Name, phone and vehicle are required." });
    const user = await User.findByIdAndUpdate(req.userId, { name, phone, vehicle }, { new: true }).select("-passwordHash");
    res.json({ user: { id: user._id, name: user.name, email: user.email, phone: user.phone, vehicle: user.vehicle } });
  } catch {
    res.status(500).json({ message: "Could not update profile." });
  }
});

export default router;
