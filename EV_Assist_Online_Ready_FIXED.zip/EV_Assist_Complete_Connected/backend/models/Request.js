import mongoose from "mongoose";

const requestSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  requestId: { type: String, required: true, unique: true },
  type: { type: String, enum: ["Breakdown", "Mechanic", "Battery", "Charging"], required: true },
  message: { type: String, default: "" },
  estimatedCost: { type: String, default: "" },
  status: { type: String, enum: ["Pending", "Accepted", "Mechanic On The Way", "Completed"], default: "Pending" },
  latitude: { type: Number, default: null },
  longitude: { type: Number, default: null },
  rating: { type: Number, min: 0, max: 5, default: 0 },
  review: { type: String, default: "" }
}, { timestamps: true });

export default mongoose.model("Request", requestSchema);
