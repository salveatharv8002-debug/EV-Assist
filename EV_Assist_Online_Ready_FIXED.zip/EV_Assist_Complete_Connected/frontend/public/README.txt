Put your existing image33.png here: public/image33.png
