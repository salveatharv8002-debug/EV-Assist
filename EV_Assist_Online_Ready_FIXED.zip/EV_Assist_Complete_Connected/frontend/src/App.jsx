const API = (import.meta.env.VITE_API_URL || "http://localhost:5000/api").replace(/\/$/, "");

const mechanics = [
  { name: "EV Care Mechanic", icon: "🔧", rating: 4.8, phone: "+91 98765 43210", service: "EV repair & roadside assistance", open: "Open 24 Hours" },
  { name: "Green EV Service Center", icon: "⚡", rating: 4.6, phone: "+91 91234 56789", service: "Electric vehicle service center", open: "Open 24 Hours" },
  { name: "Quick EV Repair", icon: "🛠️", rating: 4.7, phone: "+91 99887 66554", service: "EV roadside repair service", open: "Open 24 Hours" },
];

const stations = [
  { name: "Fast Charge Point", icon: "⚡", status: "Available", type: "Fast Charging" },
  { name: "Green Charge Hub", icon: "🔋", status: "Available", type: "EV Charging" },
  { name: "City EV Station", icon: "📍", status: "Busy", type: "Public Charging" },
];

const costs = {
  Breakdown: "₹500 - ₹1,500",
  Mechanic: "₹300 - ₹1,200",
  Battery: "₹800 - ₹4,000",
  Charging: "₹100 - ₹500",
};

function App() {
  const [page, setPage] = useState(() => localStorage.getItem("evToken") ? "home" : "login");
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem("evUser") || "null") || { name: "", email: "", phone: "", vehicle: "Electric Vehicle" });
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [signupName, setSignupName] = useState("");
  const [signupEmail, setSignupEmail] = useState("");
  const [signupPassword, setSignupPassword] = useState("");
  const [signupPhone, setSignupPhone] = useState("");
  const [location, setLocation] = useState(null);
  const [locationLoading, setLocationLoading] = useState(false);
  const [locationError, setLocationError] = useState("");
  const [darkMode, setDarkMode] = useState(() => localStorage.getItem("evDark") === "true");
  const [request, setRequest] = useState(null);
  const [history, setHistory] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [search, setSearch] = useState("");
  const [editingProfile, setEditingProfile] = useState(false);
  const [profile, setProfile] = useState(user);
  const [rating, setRating] = useState(0);
  const [review, setReview] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => { localStorage.setItem("evUser", JSON.stringify(user)); }, [user]);
  useEffect(() => { localStorage.setItem("evDark", darkMode); }, [darkMode]);

  useEffect(() => {
    const token = localStorage.getItem("evToken");
    if (!token) return;
    loadDashboard(token);
  }, []);

  const authHeaders = (json = true) => {
    const h = { Authorization: `Bearer ${localStorage.getItem("evToken") || ""}` };
    if (json) h["Content-Type"] = "application/json";
    return h;
  };

  const api = async (url, options = {}) => {
    const response = await fetch(`${API}${url}`, {
      ...options,
      headers: { ...authHeaders(!!options.body), ...(options.headers || {}) },
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      if (response.status === 401) {
        localStorage.removeItem("evToken");
        setPage("login");
      }
      throw new Error(data.message || "Request failed.");
    }
    return data;
  };

  const loadDashboard = async (token = localStorage.getItem("evToken")) => {
    if (!token) return;
    try {
      const [me, requests, notes] = await Promise.all([
        fetch(`${API}/auth/me`, { headers: { Authorization: `Bearer ${token}` } }).then(r => r.json()),
        fetch(`${API}/requests`, { headers: { Authorization: `Bearer ${token}` } }).then(r => r.json()),
        fetch(`${API}/notifications`, { headers: { Authorization: `Bearer ${token}` } }).then(r => r.json()),
      ]);
      if (me.user) {
        setUser(me.user);
        setProfile(me.user);
      }
      if (Array.isArray(requests.requests)) {
        setHistory(requests.requests);
        setRequest(requests.requests.find(x => x.status !== "Completed") || requests.requests[0] || null);
      }
      if (Array.isArray(notes.notifications)) setNotifications(notes.notifications);
    } catch (error) {
      console.error(error);
      localStorage.removeItem("evToken");
      setPage("login");
    }
  };

  const go = (name) => { setPage(name); window.scrollTo(0, 0); };

  const notify = async (title, text) => {
    try {
      const data = await api("/notifications", {
        method: "POST",
        body: JSON.stringify({ title, text }),
      });
      if (data.notification) setNotifications(n => [data.notification, ...n].slice(0, 20));
    } catch (e) {
      console.error(e);
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!loginEmail || !loginPassword) return alert("Please enter Email and Password.");
    try {
      setLoading(true);
      const data = await fetch(`${API}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: loginEmail, password: loginPassword }),
      }).then(async r => {
        const d = await r.json();
        if (!r.ok) throw new Error(d.message || "Login failed.");
        return d;
      });
      localStorage.setItem("evToken", data.token);
      setUser(data.user);
      setProfile(data.user);
      await loadDashboard(data.token);
      go("home");
    } catch (error) {
      alert(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    if (!signupName || !signupEmail || !signupPassword || !signupPhone) return alert("Please fill all fields.");
    if (signupPassword.length < 6) return alert("Password must be at least 6 characters.");
    try {
      setLoading(true);
      const data = await fetch(`${API}/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: signupName, email: signupEmail, password: signupPassword, phone: signupPhone }),
      }).then(async r => {
        const d = await r.json();
        if (!r.ok) throw new Error(d.message || "Registration failed.");
        return d;
      });
      localStorage.setItem("evToken", data.token);
      setUser(data.user);
      setProfile(data.user);
      setSignupName(""); setSignupEmail(""); setSignupPassword(""); setSignupPhone("");
      await loadDashboard(data.token);
      go("home");
    } catch (error) {
      alert(error.message);
    } finally {
      setLoading(false);
    }
  };

  const getLocation = () => {
    setLocationError("");
    if (!navigator.geolocation) return setLocationError("Geolocation is not supported by your browser.");
    setLocationLoading(true);
    navigator.geolocation.getCurrentPosition(
      p => { setLocation({ lat: p.coords.latitude, lon: p.coords.longitude }); setLocationLoading(false); },
      () => { setLocationLoading(false); setLocationError("Location permission denied. Please click Allow in Chrome."); },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  const createRequest = async (type) => {
    try {
      setLoading(true);
      const data = await api("/requests", {
        method: "POST",
        body: JSON.stringify({
          type,
          estimatedCost: costs[type],
          latitude: location?.lat || null,
          longitude: location?.lon || null,
          message: `${type} assistance requested from EV Assist.`,
        }),
      });
      if (data.request) {
        setRequest(data.request);
        setHistory(h => [data.request, ...h.filter(x => x._id !== data.request._id)]);
      }
      await notify("Request Created", `${type} assistance request ${data.request?.requestId || ""} is pending.`);
      go("status");
    } catch (error) {
      alert(error.message);
    } finally {
      setLoading(false);
    }
  };

  const advanceStatus = async () => {
    if (!request) return;
    const flow = ["Pending", "Accepted", "Mechanic On The Way", "Completed"];
    const index = flow.indexOf(request.status);
    const next = flow[index + 1];
    if (!next) return;
    try {
      setLoading(true);
      const data = await api(`/requests/${request._id}/status`, {
        method: "PATCH",
        body: JSON.stringify({ status: next }),
      });
      if (data.request) {
        setRequest(data.request);
        setHistory(h => h.map(x => x._id === data.request._id ? data.request : x));
      }
      await notify(`Request ${next}`, `${request.requestId || request._id} is now ${next}.`);
    } catch (error) {
      alert(error.message);
    } finally {
      setLoading(false);
    }
  };

  const submitReview = async () => {
    if (!request || !rating) return alert("Please select a rating.");
    try {
      const data = await api(`/requests/${request._id}/review`, {
        method: "PATCH",
        body: JSON.stringify({ rating, review }),
      });
      if (data.request) {
        setRequest(data.request);
        setHistory(h => h.map(x => x._id === data.request._id ? data.request : x));
      }
      await notify("Review Submitted", "Thank you for your feedback.");
      setRating(0); setReview("");
      alert("Review submitted successfully!");
    } catch (error) {
      alert(error.message);
    }
  };

  const saveProfile = async () => {
    if (!profile.name || !profile.phone || !profile.vehicle) return alert("Please fill all profile fields.");
    try {
      const data = await api("/profile", {
        method: "PUT",
        body: JSON.stringify({ name: profile.name, phone: profile.phone, vehicle: profile.vehicle }),
      });
      setUser(data.user);
      setProfile(data.user);
      setEditingProfile(false);
      await notify("Profile Updated", "Your profile was saved.");
    } catch (error) {
      alert(error.message);
    }
  };

  const clearNotifications = async () => {
    try {
      await api("/notifications", { method: "DELETE" });
      setNotifications([]);
    } catch (error) {
      alert(error.message);
    }
  };

  const logout = () => {
    localStorage.removeItem("evToken");
    setUser({ name: "", email: "", phone: "", vehicle: "Electric Vehicle" });
    setRequest(null);
    setHistory([]);
    setNotifications([]);
    go("login");
  };

  const filteredMechanics = useMemo(() => mechanics.filter(m => `${m.name} ${m.service}`.toLowerCase().includes(search.toLowerCase())), [search]);
  const filteredStations = useMemo(() => stations.filter(s => `${s.name} ${s.type} ${s.status}`.toLowerCase().includes(search.toLowerCase())), [search]);

  const Navbar = () => (
    <nav className="navbar">
      <div className="brand" onClick={() => go("home")}><span>⚡</span> EV Assist</div>
      <div className="nav-links">
        <button onClick={() => go("home")}>Home</button>
        <button onClick={() => go("help")}>Get Help</button>
        <button onClick={() => go("status")}>Status {request && <b className="nav-badge">1</b>}</button>
        <button onClick={() => go("history")}>History</button>
        <button onClick={() => go("notifications")}>🔔 {notifications.length ? <b className="nav-badge">{notifications.length}</b> : ""}</button>
        <button onClick={() => go("profile")}>Profile</button>
        <button onClick={() => setDarkMode(v => !v)}>🌙</button>
        <button className="logout-btn" onClick={logout}>Logout</button>
      </div>
    </nav>
  );

  const Footer = () => (
    <footer className="footer">
      <div><h2>⚡ EV Assist</h2><p>Reliable support for electric vehicle users.</p></div>
      <div><h3>Quick Links</h3><p onClick={() => go("home")}>Home</p><p onClick={() => go("help")}>Get Help</p><p onClick={() => go("about")}>About</p></div>
      <div><h3>Services</h3><p onClick={() => go("breakdown")}>Vehicle Breakdown</p><p onClick={() => go("mechanic")}>Mechanic Support</p><p onClick={() => go("battery")}>Battery Assistance</p><p onClick={() => go("charging")}>Charging Station</p></div>
      <div className="footer-bottom">© 2026 EV Assist. All Rights Reserved.</div>
    </footer>
  );

  const Shell = ({ children }) => <div className={darkMode ? "app dark" : "app"}><Navbar />{children}<Footer /></div>;

  if (page === "login") return <div className="auth-page"><div className="auth-image login-image"><div className="image-overlay"><div className="image-text"><h1>EV Assist</h1><p>Quick and reliable support for your electric vehicle.</p></div></div></div><div className="auth-box"><div className="logo-circle">⚡</div><h1>EV Assist</h1><h3>Welcome Back</h3><p className="auth-description">Get quick help for your electric vehicle.</p><form onSubmit={handleLogin}><label>Email</label><input type="email" placeholder="Enter your email" value={loginEmail} onChange={e => setLoginEmail(e.target.value)} /><label>Password</label><input type="password" placeholder="Enter your password" value={loginPassword} onChange={e => setLoginPassword(e.target.value)} /><button className="main-btn" type="submit">Login</button></form><p className="account-text">Don't have an account?</p><button className="outline-btn" onClick={() => go("signup")}>Create Account</button></div></div>;

  if (page === "signup") return <div className="auth-page"><div className="auth-image signup-image"><div className="image-overlay"><div className="image-text"><h1>Welcome to EV Assist</h1><p>Your electric vehicle support partner.</p></div></div></div><div className="auth-box"><div className="logo-circle">⚡</div><h1>Create Account</h1><p className="auth-description">Create your EV Assist account.</p><form onSubmit={handleSignup}><label>Full Name</label><input value={signupName} onChange={e => setSignupName(e.target.value)} placeholder="Enter your name" /><label>Email</label><input type="email" value={signupEmail} onChange={e => setSignupEmail(e.target.value)} placeholder="Enter your email" /><label>Phone Number</label><input type="tel" value={signupPhone} onChange={e => setSignupPhone(e.target.value)} placeholder="Enter phone number" /><label>Password</label><input type="password" value={signupPassword} onChange={e => setSignupPassword(e.target.value)} placeholder="Create password" /><button className="main-btn" type="submit">Create Account</button></form><button className="back-link" onClick={() => go("login")}>← Back to Login</button></div></div>;

  if (page === "home") return <Shell><section className="hero"><div className="hero-overlay"/><div className="hero-content"><p className="hero-small">24/7 ELECTRIC VEHICLE SUPPORT</p><h1>Your EV Breaks Down?<br/><span>We're Here to Help.</span></h1><p>Get quick help for EV breakdowns, battery problems, charging issues and nearby mechanic support.</p><div className="hero-buttons"><button className="main-btn" onClick={() => go("help")}>Get Help</button><button className="light-btn" onClick={() => go("emergency")}>🚨 Emergency</button></div></div></section><section className="services-section"><SectionTitle/><div className="service-grid"><ServiceCard icon="🚗" title="Vehicle Breakdown" text="Request roadside assistance." button="Get Breakdown Help" action={() => go("breakdown")}/><ServiceCard icon="🔧" title="Mechanic Support" text="Find nearby EV mechanics." button="Find Mechanic" action={() => go("mechanic")}/><ServiceCard icon="🔋" title="Battery Problem" text="Get battery assistance." button="Battery Help" action={() => go("battery")}/><ServiceCard icon="⚡" title="Charging Problem" text="Find nearby charging stations." button="Find Charging" action={() => go("charging")}/></div></section></Shell>;

  if (page === "help") return <Shell><InnerHero title="How Can We Help You?" sub="Select the problem with your electric vehicle."/><div className="help-grid"><ServiceCard icon="🚗" title="Vehicle Breakdown" text="Vehicle has stopped working." button="Request Help" action={() => go("breakdown")}/><ServiceCard icon="🔧" title="Mechanic Support" text="Find nearby EV mechanics." button="Find Mechanic" action={() => go("mechanic")}/><ServiceCard icon="🔋" title="Battery Problem" text="Battery is not working." button="Request Battery Help" action={() => go("battery")}/><ServiceCard icon="⚡" title="Charging Problem" text="Find charging stations." button="Find Station" action={() => go("charging")}/><ServiceCard icon="🚨" title="Emergency Assistance" text="Open the emergency assistance page." button="Emergency Help" action={() => go("emergency")}/></div></Shell>;

  if (page === "breakdown") return <Shell><InnerHero title="Vehicle Breakdown" sub="Create a roadside assistance request."/><InfoPage icon="🚗" title="Your EV Has Broken Down?" text="Create a demo assistance request and track its status from the Status page." action={() => createRequest("Breakdown")} button="Create Breakdown Request"/></Shell>;

  if (page === "battery") return <Shell><InnerHero title="Battery Assistance" sub="Get quick assistance for EV battery problems."/><InfoPage icon="🔋" title="Battery Problem?" text="Create a battery assistance request. The estimated cost is shown before the request is tracked." action={() => createRequest("Battery")} button="Request Battery Assistance"/></Shell>;

  if (page === "mechanic") return <Shell><InnerHero title="Mechanic Support" sub="Find nearby/demo EV mechanics and open them in Google Maps."/><div className="mechanic-page"><LocationBox/><SearchBox placeholder="Search mechanic..." value={search} setValue={setSearch}/><div className="mechanic-grid">{filteredMechanics.map((m, i) => <div className="mechanic-card" key={m.name}><div className="mechanic-icon">{m.icon}</div><h3>{m.name}</h3><div className="rating">⭐ {m.rating}</div><p>📍 {m.service}</p><p>📞 {m.phone}</p><p>🕒 {m.open}</p><div className="button-row"><a className="map-btn" href={location ? `https://www.google.com/maps/search/?api=1&query=EV%20mechanic%20near%20${location.lat},${location.lon}` : "https://www.google.com/maps/search/EV+mechanic+near+me"} target="_blank" rel="noreferrer">🗺️ Map</a><a className="call-btn" href={`tel:${m.phone.replaceAll(" ","")}`}>📞 Call</a></div><button className="card-btn full" onClick={() => createRequest("Mechanic")}>Request Service</button></div>)}</div></div></Shell>;

  if (page === "charging") return <Shell><InnerHero title="Charging Stations" sub="Search charging stations and open directions."/><div className="charging-page"><LocationBox/><SearchBox placeholder="Search charging station..." value={search} setValue={setSearch}/><div className="charging-grid">{filteredStations.map(s => <div className="charging-card" key={s.name}><div>{s.icon}</div><h3>{s.name}</h3><p>{s.type}</p><span className={s.status === "Available" ? "status available" : "status busy"}>{s.status}</span><a className="map-btn" href={location ? `https://www.google.com/maps/search/?api=1&query=EV%20charging%20station%20near%20${location.lat},${location.lon}` : "https://www.google.com/maps/search/EV+charging+station+near+me"} target="_blank" rel="noreferrer">🗺️ Find on Map</a><button className="card-btn full" onClick={() => createRequest("Charging")}>Request Charging Help</button></div>)}</div></div></Shell>;

  if (page === "status") return <Shell><InnerHero title="Request Status" sub="Track your latest EV assistance request."/><div className="dashboard-page">{request ? <><div className="status-card"><div className="status-top"><div><span className="small-label">REQUEST ID</span><h2>{request.requestId || request._id}</h2></div><span className={`status-pill ${request.status.toLowerCase().replaceAll(" ","-")}`}>{request.status}</span></div><p><b>Service:</b> {request.type}</p><p><b>Created:</b> {request.createdAt}</p><p><b>Estimated Cost:</b> {request.cost}</p><div className="progress">{["Pending","Accepted","Mechanic On The Way","Completed"].map((s,i)=><div className={["Pending","Accepted","Mechanic On The Way","Completed"].indexOf(request.status) >= i ? "step active" : "step"} key={s}><span>{i+1}</span><small>{s}</small></div>)}</div>{request.status !== "Completed" && <button className="main-btn" onClick={advanceStatus}>▶ Simulate Next Status</button>}{request.status === "Completed" && <div className="review-box"><h3>⭐ Rate Your Service</h3><div className="stars">{[1,2,3,4,5].map(n => <button key={n} className={rating >= n ? "star selected" : "star"} onClick={() => setRating(n)}>★</button>)}</div><textarea value={review} onChange={e => setReview(e.target.value)} placeholder="Write your review..."/><button className="main-btn" onClick={submitReview}>Submit Review</button></div>}</div></> : <Empty text="No active service request." button="Go to Get Help" action={() => go("help")}/>}</div></Shell>;

  if (page === "history") return <Shell><InnerHero title="Service History" sub="View your previous EV Assist requests."/><div className="dashboard-page">{history.length ? history.map(x => <div className="history-card" key={x._id || x.requestId}><div><h3>{x.type} Assistance</h3><p>{(x.requestId || x._id) • {new Date(x.createdAt).toLocaleString()}</p></div><div><span className="status-pill">{x.status}</span><p>Cost: {x.cost}</p>{x.rating ? <p>Rating: ⭐ {x.rating}</p> : null}</div></div>) : <Empty text="No service history yet." button="Create Request" action={() => go("help")}/>}</div></Shell>;

  if (page === "notifications") return <Shell><InnerHero title="Notifications" sub="Your latest EV Assist updates."/><div className="dashboard-page">{notifications.length ? <>{notifications.map(n => <div className="notification-card" key={n.id}><div className="notification-icon">🔔</div><div><h3>{n.title}</h3><p>{n.text}</p><small>{n.time}</small></div></div>)}<button className="dark-btn" onClick={() => setNotifications([])}>Clear Notifications</button></> : <Empty text="No notifications." button="Back Home" action={() => go("home")}/>}</div></Shell>;

  if (page === "emergency") return <Shell><InnerHero title="Emergency Assistance" sub="Use this demo screen to quickly access help options."/><div className="info-page emergency-box"><div className="big-icon">🚨</div><h2>Need Immediate Assistance?</h2><p>Get your location, open nearby services on Google Maps, or contact a support number saved in your project.</p><button className="main-btn" onClick={getLocation}>{locationLoading ? "Getting Location..." : "📍 Get My Location"}</button>{location && <a className="map-btn" href={`https://www.google.com/maps/search/?api=1&query=${location.lat},${location.lon}`} target="_blank" rel="noreferrer">🗺️ Open Location</a>}<a className="call-btn emergency-call" href="tel:+919876543210">📞 Call Demo Support</a><p className="demo-note">Demo contact only. Replace it with your real support number when connecting the backend.</p></div></Shell>;

  if (page === "profile") return <Shell><InnerHero title="My Profile" sub="Manage your EV Assist account information."/><div className="profile-page"><div className="profile-avatar">👤</div>{editingProfile ? <div className="profile-form"><label>Name</label><input value={profile.name} onChange={e => setProfile({...profile,name:e.target.value})}/><label>Email</label><input value={profile.email} disabled/><label>Phone</label><input value={profile.phone} onChange={e => setProfile({...profile,phone:e.target.value})}/><label>Vehicle</label><input value={profile.vehicle} onChange={e => setProfile({...profile,vehicle:e.target.value})}/><button className="main-btn" onClick={saveProfile}>Save Profile</button></div> : <><h2>{user.name}</h2><div className="profile-info"><div><strong>Name</strong><span>{user.name}</span></div><div><strong>Email</strong><span>{user.email || "Not added"}</span></div><div><strong>Phone</strong><span>{user.phone || "Not added"}</span></div><div><strong>Vehicle</strong><span>{user.vehicle}</span></div></div><button className="main-btn" onClick={() => setEditingProfile(true)}>✏️ Edit Profile</button></>}</div></Shell>;

  if (page === "about") return <Shell><InnerHero title="About EV Assist" sub="Smart roadside support for electric vehicle users."/><div className="about-page"><div className="about-card"><div className="big-icon">⚡</div><h2>What is EV Assist?</h2><p>EV Assist is a support platform designed for electric vehicle users. It helps users when their EV breaks down, has battery problems, charging problems or requires mechanic support.</p></div><div className="about-grid"><div><h3>🚗 Vehicle Support</h3><p>Get assistance when your electric vehicle stops working.</p></div><div><h3>🔧 Mechanic Support</h3><p>Find nearby/demo mechanics and open directions.</p></div><div><h3>🔋 Battery Support</h3><p>Create and track battery assistance requests.</p></div><div><h3>⚡ Charging Support</h3><p>Search charging stations and request help.</p></div></div></div></Shell>;

  return null;

  function LocationBox() {
    return <div className="location-card"><div className="big-icon">📍</div><h2>Find Nearby Service</h2><p>Allow location access to use your current coordinates and Google Maps search.</p><button className="main-btn" onClick={getLocation}>{locationLoading ? "Getting Location..." : "📍 Get My Location"}</button>{location && <div className="location-result"><h3>Current Location</h3><div className="coordinates"><div><strong>Latitude</strong><span>{location.lat.toFixed(6)}</span></div><div><strong>Longitude</strong><span>{location.lon.toFixed(6)}</span></div></div><a className="map-btn" href={`https://www.google.com/maps/search/?api=1&query=${location.lat},${location.lon}`} target="_blank" rel="noreferrer">🗺️ Open My Location</a></div>}{locationError && <div className="error-box">{locationError}</div>}</div>;
  }
}

function SectionTitle(){ return <div className="section-title"><p>OUR SERVICES</p><h2>How Can We Help?</h2><span>Quick assistance for your electric vehicle.</span></div>; }
function InnerHero({title,sub}){ return <section className="inner-hero"><p>EV ASSIST</p><h1>{title}</h1><span>{sub}</span></section>; }
function InfoPage({icon,title,text,action,button}){ return <div className="info-page"><div className="big-icon">{icon}</div><h2>{title}</h2><p>{text}</p><button className="main-btn" onClick={action}>{button}</button></div>; }
function Empty({text,button,action}){ return <div className="empty-card"><div>📭</div><h2>{text}</h2><button className="main-btn" onClick={action}>{button}</button></div>; }
function SearchBox({placeholder,value,setValue}){ return <div className="search-box"><span>🔎</span><input placeholder={placeholder} value={value} onChange={e=>setValue(e.target.value)}/>{value && <button onClick={()=>setValue("")}>Clear</button>}</div>; }
function ServiceCard({icon,title,text,button,action}){ return <div className="service-card"><div className="service-icon">{icon}</div><h3>{title}</h3><p>{text}</p><button className="card-btn" onClick={action}>{button} →</button></div>; }

export default App;
